package com.example.smartwash;

public class Db_Contract {

    public static String ip = "192.168.2.6";

    public static final String urlRegister = "http://"+ip+"/my_api_android//api-register.php";
    public static final String urlLogin = "http://"+ip+"/my_api_android//api-login.php";

}
