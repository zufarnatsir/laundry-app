package com.example.smartwash;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class PlaceOrderActivity extends AppCompatActivity {

    private EditText etCustomerName, etPhoneNumber, etWeight;
    private Spinner spinnerServiceType;
    private Button btnPlaceOrder;

    private ImageButton back;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_order);

        dbHelper = new DBHelper(this);

        etCustomerName = findViewById(R.id.etCustomerName);
        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        etWeight = findViewById(R.id.etWeight);
        spinnerServiceType = findViewById(R.id.spinnerServiceType);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);
        back = findViewById(R.id.back);

        loadServiceTypes();

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PlaceOrderActivity.this, MainMenuActivity.class);
                startActivity(intent);
            }
        });

        btnPlaceOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String customerName = etCustomerName.getText().toString();
                String phoneNumber = etPhoneNumber.getText().toString();
                String serviceType = spinnerServiceType.getSelectedItem().toString();
                String weightStr = etWeight.getText().toString();

                if (customerName.isEmpty() || phoneNumber.isEmpty() || weightStr.isEmpty()) {
                    Toast.makeText(PlaceOrderActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                } else {
                    double weight = Double.parseDouble(weightStr);
                    SQLiteDatabase db = dbHelper.getWritableDatabase();
                    ContentValues values = new ContentValues();
                    values.put("customerName", customerName);
                    values.put("phoneNumber", phoneNumber);
                    values.put("serviceType", serviceType);
                    values.put("weight", weight);
                    values.put("status", "Pending");

                    long newRowId = db.insert("orders", null, values);

                    if (newRowId == -1) {
                        Toast.makeText(PlaceOrderActivity.this, "Order placement failed", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(PlaceOrderActivity.this, "Order placed successfully", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void loadServiceTypes() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query("services", new String[]{"serviceName"}, null, null, null, null, null);

        ArrayList<String> serviceTypes = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                serviceTypes.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, serviceTypes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerServiceType.setAdapter(adapter);
    }
}
