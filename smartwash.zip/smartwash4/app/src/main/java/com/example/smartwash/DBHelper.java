package com.example.smartwash;

import static android.app.DownloadManager.COLUMN_ID;
import static android.app.DownloadManager.COLUMN_STATUS;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "SmartWash.db";
    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_ORDERS = "orders";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_STATUS = "status";

    private static final String TABLE_SERVICES_CREATE =
            "CREATE TABLE services (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "serviceName TEXT NOT NULL, " +
                    "price REAL NOT NULL);";

    private static final String TABLE_ORDERS_CREATE =
            "CREATE TABLE orders (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "serviceType TEXT NOT NULL, " +
                    "phoneNumber TEXT NOT NULL, " +
                    "status TEXT NOT NULL, " +
                    "weight REAL NOT NULL, " +
                    "customerName TEXT NOT NULL);";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_SERVICES_CREATE);
        db.execSQL(TABLE_ORDERS_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS orders");
        db.execSQL("DROP TABLE IF EXISTS services");
        onCreate(db);
    }

    public void updateOrderStatus(int orderId, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_STATUS, status);

        db.update(TABLE_ORDERS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(orderId)});
        db.close();
    }
}
