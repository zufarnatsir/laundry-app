package com.example.smartwash;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ManageMenuActivity extends AppCompatActivity {

    private EditText etServiceName, etServicePrice;
    private Button btnAddService, btnUpdateService, btnDeleteService;
    private ListView listViewServices;
    private ImageButton back;
    private DBHelper dbHelper;
    private int selectedServiceId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_menu);

        dbHelper = new DBHelper(this);

        etServiceName = findViewById(R.id.etServiceName);
        etServicePrice = findViewById(R.id.etServicePrice);
        btnAddService = findViewById(R.id.btnAddService);
        btnUpdateService = findViewById(R.id.btnUpdateService);
        btnDeleteService = findViewById(R.id.btnDeleteService);
        back = findViewById(R.id.back);
        listViewServices = findViewById(R.id.listViewServices);

        loadServices();

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ManageMenuActivity.this, MainMenuActivity.class);
                startActivity(intent);
            }
        });

        btnAddService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addService();
            }
        });

        btnUpdateService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateService();
            }
        });

        btnDeleteService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteService();
            }
        });

        listViewServices.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = (String) parent.getItemAtPosition(position);
                String[] parts = selectedItem.split(": Rp.");
                String serviceName = parts[0].trim();
                String servicePriceStr = parts[1].trim();

                SQLiteDatabase db = dbHelper.getReadableDatabase();
                Cursor cursor = db.query("services", new String[]{"id"}, "serviceName = ? AND price = ?", new String[]{serviceName, servicePriceStr}, null, null, null);

                if (cursor.moveToFirst()) {
                    selectedServiceId = cursor.getInt(cursor.getColumnIndex("id"));
                    etServiceName.setText(serviceName);
                    etServicePrice.setText(servicePriceStr);
                }
                cursor.close();
            }
        });
    }

    private void loadServices() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query("services", null, null, null, null, null, null);

        ArrayList<String> services = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                String service = cursor.getString(cursor.getColumnIndex("serviceName"))
                        + ": Rp." + cursor.getDouble(cursor.getColumnIndex("price"));
                services.add(service);
            } while (cursor.moveToNext());
        }
        cursor.close();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, services);
        listViewServices.setAdapter(adapter);
    }

    private void addService() {
        String serviceName = etServiceName.getText().toString();
        String servicePriceStr = etServicePrice.getText().toString();

        if (serviceName.isEmpty() || servicePriceStr.isEmpty()) {
            Toast.makeText(ManageMenuActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
        } else {
            double servicePrice = Double.parseDouble(servicePriceStr);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("serviceName", serviceName);
            values.put("price", servicePrice);

            long newRowId = db.insert("services", null, values);

            if (newRowId == -1) {
                Toast.makeText(ManageMenuActivity.this, "Service addition failed", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(ManageMenuActivity.this, "Service added successfully", Toast.LENGTH_SHORT).show();
                loadServices();
                clearFields();
            }
        }
    }

    private void updateService() {
        if (selectedServiceId == -1) {
            Toast.makeText(ManageMenuActivity.this, "Please select a service to update", Toast.LENGTH_SHORT).show();
            return;
        }

        String serviceName = etServiceName.getText().toString();
        String servicePriceStr = etServicePrice.getText().toString();

        if (serviceName.isEmpty() || servicePriceStr.isEmpty()) {
            Toast.makeText(ManageMenuActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
        } else {
            double servicePrice = Double.parseDouble(servicePriceStr);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("serviceName", serviceName);
            values.put("price", servicePrice);

            int rowsAffected = db.update("services", values, "id = ?", new String[]{String.valueOf(selectedServiceId)});

            if (rowsAffected == 0) {
                Toast.makeText(ManageMenuActivity.this, "Service update failed", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(ManageMenuActivity.this, "Service updated successfully", Toast.LENGTH_SHORT).show();
                loadServices();
                clearFields();
                selectedServiceId = -1;
            }
        }
    }

    private void deleteService() {
        if (selectedServiceId == -1) {
            Toast.makeText(ManageMenuActivity.this, "Please select a service to delete", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int rowsDeleted = db.delete("services", "id = ?", new String[]{String.valueOf(selectedServiceId)});

        if (rowsDeleted == 0) {
            Toast.makeText(ManageMenuActivity.this, "Service deletion failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(ManageMenuActivity.this, "Service deleted successfully", Toast.LENGTH_SHORT).show();
            loadServices();
            clearFields();
            selectedServiceId = -1;
        }
    }

    private void clearFields() {
        etServiceName.setText("");
        etServicePrice.setText("");
    }
}
