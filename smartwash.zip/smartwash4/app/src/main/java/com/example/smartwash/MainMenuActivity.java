package com.example.smartwash;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainMenuActivity extends AppCompatActivity {

    private TextView btnPlaceOrder, btnViewOrders, btnManageMenu, teksLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);
        btnViewOrders = findViewById(R.id.btnViewOrders);
        btnManageMenu = findViewById(R.id.btnManageMenu);
        teksLogout = findViewById(R.id.teksLogout);

        btnPlaceOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainMenuActivity.this, PlaceOrderActivity.class);
                startActivity(intent);
            }
        });

        btnViewOrders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainMenuActivity.this, ViewOrderActivity.class);
                startActivity(intent);
            }
        });

        btnManageMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainMenuActivity.this, ManageMenuActivity.class);
                startActivity(intent);
            }
        });

        teksLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainMenuActivity.this, Login.class);
                startActivity(intent);
            }
        });
    }
}
