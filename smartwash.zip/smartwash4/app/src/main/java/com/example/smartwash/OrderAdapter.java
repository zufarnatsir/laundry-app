package com.example.smartwash;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.borders.Border;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

public class OrderAdapter extends ArrayAdapter<Order> {

    private DBHelper dbHelper;

    public OrderAdapter(Context context, List<Order> orders) {
        super(context, 0, orders);
        dbHelper = new DBHelper(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.order_list_item, parent, false);
        }

        Order currentOrder = getItem(position);

        TextView customerNameTextView = listItemView.findViewById(R.id.tvCustomerName);
        TextView phoneNumberTextView = listItemView.findViewById(R.id.tvPhoneNumber);
        TextView serviceTypeTextView = listItemView.findViewById(R.id.tvServiceType);
        TextView weightTextView = listItemView.findViewById(R.id.tvWeight);
        TextView totalPriceTextView = listItemView.findViewById(R.id.tvTotalPrice);
        TextView statusTextView = listItemView.findViewById(R.id.tvStatus);

        customerNameTextView.setText(currentOrder.getCustomerName());
        phoneNumberTextView.setText(currentOrder.getPhoneNumber());
        serviceTypeTextView.setText(currentOrder.getServiceType());
        weightTextView.setText(String.valueOf(currentOrder.getWeight()));
        totalPriceTextView.setText(String.valueOf(currentOrder.getTotalPrice()));
        statusTextView.setText(currentOrder.getStatus());

        Button btnChangeStatus = listItemView.findViewById(R.id.btnChangeStatus);
        Button btnCreatePDF = listItemView.findViewById(R.id.btnCreatePDF);

        btnChangeStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentOrder.setStatus("Done");
                dbHelper.updateOrderStatus(currentOrder.getId(), "Done");
                notifyDataSetChanged();
            }
        });

        btnCreatePDF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    createPdf(currentOrder);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                    Toast.makeText(getContext(), "Error creating PDF", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return listItemView;
    }

    private void createPdf(Order order) throws FileNotFoundException {
        String filePath = getContext().getExternalFilesDir(null) + "/Order_" + order.getId() + ".pdf";
        File file = new File(filePath);
        OutputStream outputStream = new FileOutputStream(file);

        PdfWriter writer = new PdfWriter(outputStream);
        PdfDocument pdfDocument = new PdfDocument(writer);
        Document document = new Document(pdfDocument);

        // Header
        document.add(new Paragraph("Smartwash Invoice").setFontSize(18).setBold().setTextAlignment(TextAlignment.CENTER));

        // Space
        document.add(new Paragraph().setFontSize(14));

        // Data Output
        String customerName = order.getCustomerName();
        String phoneNumber = order.getPhoneNumber();
        String serviceType = order.getServiceType();
        String weight = String.valueOf(order.getWeight());
        String totalPrice = String.valueOf(order.getTotalPrice());
        String status = order.getStatus();

        // Table
        float[] columnWidths = {300f, 300f};
        Table table = new Table(columnWidths);
        table.addCell(new Cell().add(new Paragraph("Nama Customer: " + customerName).setFontSize(12).setTextAlignment(TextAlignment.LEFT).setBorder(Border.NO_BORDER)));
        table.addCell(new Cell().add(new Paragraph("Nomor Telpon: " + phoneNumber).setFontSize(12).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER)));
        table.addCell(new Cell().add(new Paragraph("Tipe Service: " + serviceType).setFontSize(12).setTextAlignment(TextAlignment.LEFT).setBorder(Border.NO_BORDER)));
        table.addCell(new Cell().add(new Paragraph("Berat: " + weight + " kg").setFontSize(12).setTextAlignment(TextAlignment.LEFT).setBorder(Border.NO_BORDER)));
        table.addCell(new Cell().add(new Paragraph("Total Harga: Rp." + totalPrice).setFontSize(12).setTextAlignment(TextAlignment.LEFT).setBorder(Border.NO_BORDER)));
        table.addCell(new Cell().add(new Paragraph("Status: " + status).setFontSize(12).setTextAlignment(TextAlignment.LEFT).setBorder(Border.NO_BORDER)));
        document.add(table);


        document.close();

        Toast.makeText(getContext(), "PDF Created: " + filePath, Toast.LENGTH_SHORT).show();
    }
}
