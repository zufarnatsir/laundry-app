package com.example.smartwash;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ViewOrderActivity extends AppCompatActivity {

    private ListView listViewOrders;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_order);

        dbHelper = new DBHelper(this);

        listViewOrders = findViewById(R.id.listViewOrders);

        loadOrders();
    }

    private void loadOrders() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query("orders", null, null, null, null, null, null);

        ArrayList<Order> orders = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                String customerName = cursor.getString(cursor.getColumnIndex("customerName"));
                String phoneNumber = cursor.getString(cursor.getColumnIndex("phoneNumber"));
                String serviceType = cursor.getString(cursor.getColumnIndex("serviceType"));
                double weight = cursor.getDouble(cursor.getColumnIndex("weight"));
                String status = cursor.getString(cursor.getColumnIndex("status"));

                double totalPrice = calculateTotalPrice(serviceType, weight);

                Order order = new Order(id, customerName, phoneNumber, serviceType, weight, status, totalPrice);
                orders.add(order);
            } while (cursor.moveToNext());
        }
        cursor.close();

        OrderAdapter adapter = new OrderAdapter(this, orders);
        listViewOrders.setAdapter(adapter);
    }

    private double calculateTotalPrice(String serviceType, double weight) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query("services", new String[]{"price"}, "serviceName=?", new String[]{serviceType}, null, null, null);
        double pricePerKg = 0;
        if (cursor.moveToFirst()) {
            pricePerKg = cursor.getDouble(cursor.getColumnIndex("price"));
        }
        cursor.close();
        return weight * pricePerKg;
    }
}
